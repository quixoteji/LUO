from generate import generate_b
from generate import generate_f
from generate import generate_h

a = generate_b(5)
b = generate_f(5)
c = generate_h(5)
print(a)
print(b)
print(c)