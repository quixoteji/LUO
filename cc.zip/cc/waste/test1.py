def A(self, num):
    return num**3