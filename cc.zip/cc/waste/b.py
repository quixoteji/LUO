from a import A,B

print(A(1,2), B(1,2))