
def A(a,b):
    return a+b

def B(a, b):
    return a-b