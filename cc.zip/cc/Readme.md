# Efficient Secure Outsoucing of Large-scale Nonlinear Programming with Nonlinear Constraints

## Reqirements
- numpy
- scipy
- sympy

## GPM (Gradient Projection Method)

Objective: min f(x)

constraints: g(x)

1. Initial x1, r, k = 1, delta_f(x), N
2. Reapeat:
3. 

## SGPM (Secure Gradient Projection Method)
