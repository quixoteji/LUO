class test(object):
    pass