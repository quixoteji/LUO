import numpy as np



class state(object):
    # Define a state of NLOP
    def __init__(self, nMBS, nSBS, nUE):
        self.nMBS = nMBS
        self.nSBS = nSBS
        self.nUE = nUE
    
    def stateGenerate():
        